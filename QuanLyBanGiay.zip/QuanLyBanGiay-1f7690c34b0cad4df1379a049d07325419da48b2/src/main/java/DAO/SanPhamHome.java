package DAO;

import entity1.Sanpham;

public class SanPhamHome extends Generic_Implement<Sanpham> {
		
}
