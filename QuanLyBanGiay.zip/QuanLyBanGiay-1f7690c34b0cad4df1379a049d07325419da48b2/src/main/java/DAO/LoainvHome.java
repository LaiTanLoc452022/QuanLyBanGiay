package DAO;
// Generated Mar 30, 2023, 7:14:19 PM by Hibernate Tools 5.6.12.Final

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Example;
import entity1.*;
/**
 * Home object for domain model class Loainv.
 * @see DAO.Loainv
 * @author Hibernate Tools
 */
public class LoainvHome extends Generic_Implement<Loainv>{

	
}
 